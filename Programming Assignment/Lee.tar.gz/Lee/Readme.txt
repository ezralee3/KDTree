Ezra Lee, e.lee1@ufl.edu

Since the source code is written in python3, to run the code type "python3" then the name of the source
code file, "rangeQ.py", along with the respective arguments. A sample command to run is "python3 rangeQ.py 1 database.txt queries.txt 50". 
The resulting output files will appear in the same directory.

For the kd-tree algorithm (number 1), there is a bug where points will get duplicated in other parts of the tree. Also,
none of my algorithms can handle data dimensions greater than 2. 

